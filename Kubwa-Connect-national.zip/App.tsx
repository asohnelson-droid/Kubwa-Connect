

import React, { useState, useEffect, useCallback, useRef, Suspense } from 'react';
import { Home as HomeIcon, ShoppingBag, Wrench, Truck, User, Loader2, X } from 'lucide-react';
import { AppSection, UserRole, CartItem, User as UserType } from './types';
import SetupWizard from './components/SetupWizard';
import LocationPrompt from './components/LocationPrompt';
import { api } from './services/data';
import { supabase } from './services/supabase';
import { useData } from './contexts/DataContext';

// Lazy Load Pages for Performance Optimization
const Home = React.lazy(() => import('./pages/Home'));
const Mart = React.lazy(() => import('./pages/Mart'));
const FixIt = React.lazy(() => import('./pages/FixIt'));
const Deliveries = React.lazy(() => import('./pages/Deliveries'));
const Admin = React.lazy(() => import('./pages/Admin'));
const Account = React.lazy(() => import('./pages/Account'));
const InfoPages = React.lazy(() => import('./pages/InfoPages'));
const Onboarding = React.lazy(() => import('./pages/Onboarding'));

function App() {
  const [currentSection, setCurrentSection] = useState<AppSection>(AppSection.HOME);
  const [history, setHistory] = useState<AppSection[]>([]); // Navigation History Stack
  const [user, setUser] = useState<UserType | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const isRefreshingRef = useRef(false);
  const hasInitializedRef = useRef(false);

  // Use DataContext for cart state
  const { cart, setCart, addToCart, setBrowse } = useData();
  const browseDefaultKeyRef = useRef<string | null>(null);
  
  const [authIntent, setAuthIntent] = useState<{ section: AppSection; role: UserRole } | null>(null);

  /**
   * NAVIGATION LOGIC
   * Manages history stack to allow standardized "Back" functionality
   */
  const navigateTo = useCallback((section: AppSection) => {
    setCurrentSection(prevSection => {
      if (section === prevSection) return prevSection;
      setHistory(prevHistory => [...prevHistory, prevSection]);
      window.history.pushState({ appSection: section }, '');
      return section;
    });
  }, []);

  const goBack = useCallback(() => {
    window.history.back();
  }, []);

  // Single source of truth for "back", regardless of whether it's triggered
  // by the device's physical/gesture back button or an in-app back button
  // (which now also just calls window.history.back() above) -- both funnel
  // through this one listener, so behavior is identical either way.
  useEffect(() => {
    window.history.replaceState({ appSection: AppSection.HOME }, '');

    const handlePopState = () => {
      setHistory(prevHistory => {
        if (prevHistory.length === 0) {
          setCurrentSection(AppSection.HOME);
          return prevHistory;
        }
        const newHistory = [...prevHistory];
        const prev = newHistory.pop();
        if (prev !== undefined) setCurrentSection(prev);
        return newHistory;
      });
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  /**
   * STABLE USER REFRESH
   */
  const refreshUser = useCallback(async (targetSection?: AppSection) => {
    if (isRefreshingRef.current) return;
    isRefreshingRef.current = true;
    try {
      const currentUser = await api.auth.getSession();
      setUser(currentUser);
      if (currentUser && targetSection) {
        navigateTo(targetSection);
      }
      return currentUser;
    } catch (err) {
      setUser(null);
      return null;
    } finally {
      isRefreshingRef.current = false;
    }
  }, [navigateTo]);

  /**
   * DEFAULT BROWSING AREA
   * When a member signs in or changes location, Mart/FixIt/Home start on
   * their own city if it is live, otherwise on all of Nigeria. A manual
   * choice in the location chip stays until the next sign-in or move.
   */
  useEffect(() => {
    const key = user ? `${user.id}:${user.cityId ?? ''}` : 'guest';
    if (browseDefaultKeyRef.current === key) return;
    const firstRun = browseDefaultKeyRef.current === null;
    browseDefaultKeyRef.current = key;
    if (!user) {
      if (!firstRun) setBrowse({ scope: 'NATIONAL', label: 'All Nigeria' });
      return;
    }
    api.locations.getCities().then(cities => {
      const city = user.cityId ? cities.find(c => c.id === user.cityId) : undefined;
      setBrowse(city?.isLive ? { scope: 'CITY', cityId: city.id, label: city.name } : { scope: 'NATIONAL', label: 'All Nigeria' });
    });
  }, [user?.id, user?.cityId, setBrowse]);

  /**
   * APP LIFECYCLE
   */
  useEffect(() => {
    let mounted = true;

    const bootApp = async () => {
      if (hasInitializedRef.current) return;
      
      const currentUser = await refreshUser();
      if (!mounted) return;

      let hasSeenOnboarding = false;
      try {
        hasSeenOnboarding = localStorage.getItem('kubwa_onboarding_seen') === 'true';
      } catch (e) {}
      
      // CRITICAL: Onboarding only if truly first time and NOT logged in
      if (!currentUser && !hasSeenOnboarding) {
        setShowOnboarding(true);
      }

      setIsInitializing(false);
      hasInitializedRef.current = true;
    };

    bootApp();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      // Avoid looping if we're already initializing
      if (isInitializing && hasInitializedRef.current) return;

      if (['SIGNED_IN', 'TOKEN_REFRESHED', 'USER_UPDATED'].includes(event)) {
        if (mounted) await refreshUser();
      } else if (event === 'SIGNED_OUT') {
        if (mounted) {
          setUser(null);
          setCurrentSection(AppSection.HOME);
          setHistory([]);
          window.history.replaceState({ appSection: AppSection.HOME }, '');
        }
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [refreshUser, isInitializing]);

  const handleOnboardingComplete = () => {
    try {
      localStorage.setItem('kubwa_onboarding_seen', 'true');
    } catch (e) {
      localStorage.removeItem('kubwa_cart');
      try {
        localStorage.setItem('kubwa_onboarding_seen', 'true');
      } catch (retryErr) {}
    }
    setShowOnboarding(false);
  };

  const renderContent = () => {
    if (currentSection === AppSection.ADMIN && user?.role !== 'ADMIN' && user?.role !== 'SUPER_ADMIN') {
        return <Home setSection={navigateTo} user={user} setAuthIntent={setAuthIntent} refreshUser={refreshUser} />;
    }

    switch (currentSection) {
      case AppSection.HOME: return <Home setSection={navigateTo} user={user} setAuthIntent={setAuthIntent} refreshUser={refreshUser} />;
      case AppSection.MART: return <Mart addToCart={addToCart} cart={cart} setCart={setCart} user={user} onRequireAuth={() => navigateTo(AppSection.ACCOUNT)} setSection={navigateTo} refreshUser={refreshUser} goBack={goBack} />;
      case AppSection.FIXIT: return <FixIt user={user} onRequireAuth={() => navigateTo(AppSection.ACCOUNT)} setSection={navigateTo} refreshUser={refreshUser} goBack={goBack} />;
      case AppSection.RIDE: return <Deliveries user={user} onRequireAuth={() => navigateTo(AppSection.ACCOUNT)} setSection={navigateTo} refreshUser={refreshUser} goBack={goBack} />;
      case AppSection.ADMIN: return <Admin currentUser={user} />;
      case AppSection.ACCOUNT: return <Account user={user} setUser={setUser} setSection={navigateTo} authIntent={authIntent} clearAuthIntent={() => setAuthIntent(null)} refreshUser={refreshUser} goBack={goBack} />;
      case AppSection.ABOUT:
      case AppSection.PRIVACY:
      case AppSection.TERMS:
      case AppSection.CONTACT:
      case AppSection.FAQ: return <InfoPages section={currentSection} setSection={navigateTo} goBack={goBack} user={user} />;
      default: return <Home setSection={navigateTo} user={user} setAuthIntent={setAuthIntent} refreshUser={refreshUser} />;
    }
  };

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center">
         <div className="w-16 h-16 bg-kubwa-ink rounded-3xl animate-bounce flex items-center justify-center shadow-xl p-3.5">
            <svg viewBox="0 0 200 200" className="w-full h-full">
              <g stroke="currentColor" strokeLinecap="round" fill="none">
                <path d="M 55 30 L 55 170" stroke="#16A34A" strokeWidth="38"/>
                <path d="M 55 100 L 155 30" stroke="#F59E0B" strokeWidth="38"/>
                <path d="M 55 100 L 155 170" stroke="#2563EB" strokeWidth="38"/>
              </g>
            </svg>
         </div>
         <p className="mt-6 text-xs font-bold text-gray-500">Syncing app state...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kubwa-surface max-w-md mx-auto relative shadow-2xl overflow-hidden font-sans border-x border-gray-100">
      <Suspense fallback={
         <div className="fixed inset-0 z-50 bg-white flex flex-col items-center justify-center">
           <Loader2 className="animate-spin text-kubwa-primary" size={40} />
         </div>
      }>
        {showOnboarding && <Onboarding onComplete={handleOnboardingComplete} />}
      </Suspense>
      
      {user && !user.isSetupComplete && (
        <SetupWizard 
          user={user} 
          onComplete={(updatedUser) => {
            setUser(updatedUser);
            refreshUser(updatedUser.role === 'ADMIN' ? AppSection.ADMIN : AppSection.ACCOUNT);
          }} 
        />
      )}
      
      {user && user.isSetupComplete && !user.lgaId && (
        <LocationPrompt user={user} onSaved={() => refreshUser()} />
      )}

      <div className="h-screen overflow-y-auto no-scrollbar bg-white pb-32">
         <Suspense fallback={
           <div className="h-full flex items-center justify-center">
             <Loader2 className="animate-spin text-kubwa-primary" size={32} />
           </div>
         }>
           {renderContent()}
         </Suspense>
      </div>

      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-white/95 backdrop-blur-xl border-t border-gray-100 px-4 py-3 flex justify-between items-center z-40 rounded-t-[2rem] shadow-2xl">
        {[
          { id: AppSection.HOME, icon: HomeIcon, label: 'Home' },
          { id: AppSection.MART, icon: ShoppingBag, label: 'Mart' },
          { id: AppSection.FIXIT, icon: Wrench, label: 'FixIt' },
          { id: AppSection.RIDE, icon: Truck, label: 'Ride' },
          { id: AppSection.ACCOUNT, icon: User, label: user ? 'Profile' : 'Join' }
        ].map((item) => {
          const isActive = currentSection === item.id;
          return (
            <button
              key={item.id}
              onClick={() => navigateTo(item.id)}
              className="flex flex-col items-center gap-1 transition-all"
            >
              <div className={`p-2.5 rounded-2xl transition-all ${isActive ? 'bg-kubwa-primary/10' : ''}`}>
                <item.icon size={20} strokeWidth={isActive ? 2.5 : 2} className={isActive ? 'text-kubwa-primary' : 'text-gray-500'} />
              </div>
              <span className={`text-[11px] transition-all ${isActive ? 'font-bold text-kubwa-primary' : 'font-semibold text-gray-500'}`}>{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default App;